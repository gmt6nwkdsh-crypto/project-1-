# Handoff: Andrade Macros — dark flow (landing, onboarding, Today, Log food, Weight, Insights)

## Overview
A refresh of the existing phone-first app in `gmt6nwkdsh-crypto/project-1-` (`public/index.html`). It keeps the app's current dark "nutrition label" identity and adds/reworks:
- Welcome/landing with 3 tap-through slides
- A 5-step onboarding that computes daily targets
- Today dashboard: day picker, label card, **weekly protein card (new)**, foldable meals, inline "+ Add to {meal}"
- Log food bottom sheet: meal picker + Snap / Describe / Label / Manual, editable estimate review
- Weight tab: trend chart with plan line, range switch, stat tiles, weigh-in form, recent list
- Insights tab: computed weekly verdict, averages, tappable calories-by-day bars, most-logged foods

## About the Design Files
`Andrade Macros Prototype.dc.html` is a **design reference built in HTML**, not production code. Recreate it inside the existing app (`public/index.html` is vanilla HTML/CSS/JS with template-string rendering and CSS custom properties). Reuse the existing classes where they already exist (`.label`, `.meal`, `.card`, `.tile`, `.seg`, `.btn`, `.sheet`, `.tabs`, `.wl*`, `.wlist`, `.entry`) and add new ones only for new pieces. Wire to the real APIs (`api/doc.js` for settings/logs/weigh-ins, `api/ai.js` for estimates); the prototype's estimates are canned.

`Andrade Macros Mockups.dc.html` holds the earlier exploration (light alternatives, option ids 1a–1f, 2a). The chosen direction is the dark one: 1a, 1c, 2a.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii and copy are final. Match them.

## Design Tokens (already in the app's `:root`)
| Token | Value | Use |
|---|---|---|
| --bg | #07060a | page |
| --surface | #13101b | cards, sheet, tab bar |
| --ink | #efeaf7 | text, label borders |
| --muted | #9c93ad | secondary text |
| --line | #2a2338 | borders, tracks, pressed seg |
| --accent | #9b5cff | primary buttons, focus rings, selected bar |
| --pro | #38c6d9 | protein |
| --carb | #f2b84b | carbs |
| --fat | #ff6fae | fat |
| --good | #4ade80 | "On track", lost-weight tile |
| --warn | #ff7a59 | calories-by-day bar when >108% of goal |
| selected option bg | #1c1528 | onboarding option / method button when selected |
| link text | #b98cff | "+ Add to Dinner" |

Type: `--display` Archivo (variable, uses `font-stretch`), `--body` Figtree. Display patterns:
- Hero H1: 900, stretch 70%, 46px (onboarding 42px), line-height .95, `text-wrap:balance`
- Label title: 900, stretch 66–72%, 38–58px
- Card heading: 800, stretch 85%, 17px, uppercase, letter-spacing .02em
- Big numbers: 900, stretch 66–75%, 22–64px
- Field label: Figtree 12px, uppercase, letter-spacing .06em, muted
- Body 15px/1.45; lede 16px/1.5 muted

Radii: card 14, sheet top 20, buttons 10–14, big CTA 14, pills 999, seg outer 12/inner 9. Phone side padding 16 (app) / 20 (landing/onboarding).

## Screens

### 1. Landing (option 1a)
- Top row: brand "Andrade Macros" (Archivo 800/80%/20px) + "Free · no email" muted 13px.
- 3 progress dashes (grid 3 cols, gap 6, 4px tall, radius 2). Filled = ink for index ≤ current, otherwise line. Clicking a dash jumps to that slide.
- The art + headline block is one button: tap → next slide (wraps).
  - Slide 0: Nutrition Facts label (3px ink border, surface bg, 12/14/14 padding). Title 58px; sub row "Your day · Sat, Oct 3 / 4 meals" with a 12px ink bottom border; Calories row with a 6px border; 3 macro rows with 7px bars. H1 "Read your day like a label."
  - Slide 1: square photo area with 4 corner brackets, a scan line (2px accent + glow), 2 food tags, a "540 Cal" pill. H1 "Snap your plate. Get your macros."
  - Slide 2: 3 concentric rings (r 112/86/60, stroke 18, track = line), center "1,612 / of 1,870 Cal", legend. H1 "Hit your numbers, every day."
- Bottom (margin-top:auto): "Get started" (accent, 16px padding, 17px, radius 14) → onboarding. "I already have an account" (quiet) → sign-in (in the prototype it goes straight to Today).

### 2. Onboarding (option 1c)
- Header: 44×44 back button (surface, 1px line, radius 10), "Step N of 5" centered. Back on step 1 returns to landing.
- 5 dashes, then H1 + lede, then step body, then the CTA at the bottom.
- Steps and copy:
  1. "What are we aiming for?" / "No wrong answer. You can change it any time." Options: Lose weight (Slow and steady, no crash diets) · Stay where I am (Eat well, keep it even) · Build muscle (A small surplus, plenty of protein)
  2. "A bit about you" / "Used only to estimate how much you burn. Stays on your account." Female/Male seg; steppers for Age (14–99), Height (48–84 in, shown as 5′ 6″), Weight (80–400 lb), each with 44px −/+ buttons.
  3. "How active is a normal day?" / "Think of a typical weekday, not your best one." Mostly sitting · On my feet some · Active · Very active (each with a sub line)
  4. "How fast?" / "Slower is easier to stick with." Gentle / Steady / Faster = 0.5 / 1 / 1.5 lb a week (for gain the subs show half those numbers). If the goal is maintain: title "Staying even", lede "No pace needed. We’ll aim right at what you burn.", no options.
  5. "Here are your numbers": a label "Your Daily Numbers" showing the goal label and "maintain ≈ TDEE", Calories, and P/C/F grams with color dots. Footnote "You can change any of these later in Settings."
- Option card: radius 14, padding 16, min-height 64. Unselected: surface + inset 1px line. Selected: #1c1528 + inset 2px accent + "●" at the right.
- CTA "Continue"; on the last step "Looks right, start logging" → save to settings, go to Today, toast "Your plan is set".
- Target math (Mifflin-St Jeor): BMR = 10·kg + 6.25·cm − 5·age + (male ? 5 : −161); TDEE = BMR × {1.2, 1.375, 1.55, 1.725}. Calories = TDEE − pace·500 (lose), + pace·250 (gain), or TDEE (maintain), rounded to 10. Protein = 0.8 g × lb. Fat = 27% of calories ÷ 9. Carbs = the rest ÷ 4. **Swap in the app's existing formula if it already has one.**

### 3. Today (option 2a)
- Day picker: 7 columns, gap 4, min-height 56, radius 12. Selected: ink bg with bg-colored text. Others: surface with muted text, plus a 5px dot.
- Label card: surface, 2px ink border. Title "Today" or "Monday, Sep 28"; sub "Goal {cal} Cal / {n} items" with a 10px border; Calories with a 5px border; macro rows "Protein 89g / 136g … 65%" with 6px bars (width transition .5s cubic-bezier(.2,.7,.2,1), capped at 100%); footer "{x} Cal left" or "{x} Cal over", and "{g}g protein to go" or "Protein done ✓".
- **This week card (new):** surface, radius 14, padding 14. Heading "THIS WEEK" with "{hits} of {done}" in protein color. Copy: "You hit protein **{hits} of the last {done} days**." plus a note: "Breakfast is doing most of the work, so keep the eggs." when hits ≥ 4, otherwise "Try adding a protein snack in the afternoon." Below it, 7 dots (22px): protein color = hit (≥ 95% of the protein goal), line color = miss, today gets a 2px ring.
- Meals: Breakfast/Lunch/Dinner/Snacks cards. The header is a button that toggles fold (▾/▸) and shows the meal total. Item row: name 600; under it "{amt} · {p}P {c}C {f}F" in macro colors; calories on the right. An empty meal shows "+ Add to {meal}", which opens the sheet with that meal preselected.
- FAB "+ Log food" (accent pill, bottom 96, right 16), Today tab only.
- Tab bar: absolute bottom 24, surface, 1px line, radius 16, 3 cols. Current tab has bg-colored fill.

### 4. Log food sheet
- Shade rgba(0,0,0,.7). Sheet: surface, top radius 20, max-height 90%, padding 16/16/28, gap 14.
- Header "Log food" (Archivo 900/80%/26px) + Close.
- Meal seg (4 columns) and method buttons (4 columns: Snap, Describe, Label, Manual; selected uses inset accent ring + #1c1528).
- Snap: 4:3 camera area + "Take photo" + tip "Tip: shoot from above, everything in frame." Label: dashed 4:3 area + "Scan label". Describe: textarea (placeholder "What did you eat? e.g. two carne asada tacos with pico"), 3 idea chips that fill the textarea, "Estimate". Manual: Food, then Cal/Prot/Carb/Fat number fields, then "Add to {meal}".
- Loading: spinner (18px, 2px line border, accent top, .8s linear) + "Estimating…". In the app this is the `api/ai.js` call.
- Review: "Here's what I see. Untick anything that's wrong, or change the amount." Each row has a checkbox (24px, 2px accent border, filled when on), name, macros, and −/+ steppers that scale servings by 0.25 (min 0.25). Unticked rows drop to 45% opacity. Then a Total row, "Add N items to {meal}" (disabled text "Nothing selected" if none are ticked), and "Start over".
- On add: append items to today's meal, unfold that meal, close the sheet, switch to Today, and show the toast "Added N items to {meal}" (ink pill at the top, 2.4s).
- Errors: surface the messages `api/ai.js` already returns (rate_limited, ai_off, image_rejected…) inline above the CTA.

### 5. Weight
- Header: "TREND WEIGHT", then a 64px number + "lb". Right side: "Last weigh-in / {w} lb · {date}".
- Chart card: range seg (4 weeks / 8 weeks / All = last 7 / 15 / all points). SVG 330×150, non-scaling strokes. Raw weigh-ins: muted 1px line at 50% opacity. Trend: accent 3px. Plan: dashed sloped line from the plan value at the first visible date to the last (plan = first trend − pace × weeks elapsed). The y-range includes the plan values, padded 0.5 lb. Footer: first date · "dashed = plan" · last date, in monospace 11px.
- Trend = exponential smoothing, α = 0.25.
- Tiles: Lost (good color, "since {first date}"), Per week ("plan −{pace}"), Status ("On plan / keep going" if rate ≥ 0.8 × pace, otherwise "Slower / check portions").
- Weigh in: number input (placeholder = last weight) + Save. Valid range 50–700; replaces today's entry if one exists. Toast "Saved {w} lb".
- Recent weigh-ins: last 6, newest first, "trend {t}", × delete.

### 6. Insights
- "Sep 27 – Oct 3" / H1 "Your week".
- Verdict card (2px ink border). Tag "On track" (good) if the weight rate is on plan and average calories are within 6% over goal; otherwise "Worth a look" (carb color). Copy: "{Down|Up} **{x} lb** this week, averaging {rate} lb/wk since {date}, {on track with | a bit under} your {pace} lb plan. Protein is the win: **{hits} of {done} days**. {Calories stayed close to your goal. | Calories ran about {n} over goal on average, mostly {heaviest day}.}"
- Tiles: Avg Cal (goal), Avg protein (goal), Logged 7/7.
- Calories by day: 7 bars (150px tall area, radius 6/6/2/2), a dashed goal line, and day labels. Bar colors: selected = accent, over 108% of goal = warn, otherwise line. Tapping a bar shows "{Day} · {cal} Cal · {p}g protein" (today shows "Today so far").
- Most logged: name, "logged {n}× · {cal} Cal each", protein on the right. The existing top-foods logic in index.html already produces this.

## State
`screen` (landing|onb|app), `tab`, `stepA`, `profile {goal, sex, age, height, weight, activity, pace}` → targets; `dayA` (selected day); `closed{meal}`; `sheet`, `meal`, `method`, `phase` (idle|busy|done), `est[] {name, amt, unit, cal, p, c, f, x, on}`; `desc`; `man{}`; `weights[] {date, w}`; `range`; `insDay`; `toast`. Persist the profile, logs and weights through `api/doc.js` as the app does today.

## Assets
No new images. The photo areas are placeholders (the camera preview and the user's photo go there). The app icon stays `public/icon.svg`.

## Files
- `Andrade Macros Prototype.dc.html` — the clickable reference (open it in a browser; the pills above the phone jump between screens)
- `Andrade Macros Mockups.dc.html` — exploration; the chosen options are 1a, 1c and 2a
